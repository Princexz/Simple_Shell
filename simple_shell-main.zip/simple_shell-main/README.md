# simple_shell
A project to wrap up sprint 1 of Alx SE program. Done by by two persons
